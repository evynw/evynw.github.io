window.addEventListener("load", function() {
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentHours1 = currentTime.getHours() - 1;
var currentHours2 = currentTime.getHours() + 1;
var Minutes1 = currentTime.getMinutes() - 1;
var Minutes2 = currentTime.getMinutes() + 1;
var Minutes0 = currentTime.getMinutes();
var currentMinutes = Minutes0 < 10 ? '0' + Minutes0 : Minutes0;
var currentMinutes1 = Minutes1 < 10 ? '0' + Minutes1 : Minutes1;
var currentMinutes2 = Minutes2 < 10 ? '0' + Minutes2 : Minutes2;
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentMonth = currentTime.getMonth() + 1;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";


if (Clock == "24h"){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours1 = ( currentHours1 < 10 ? "0" : "" ) + currentHours1;
	currentHours2 = ( currentHours2 < 10 ? "0" : "" ) + currentHours2;
	if (currentTime.getHours() == 0){currentHours2 = "01";}
	if (currentTime.getHours() == 0){currentHours1 = "23";}
	if (currentTime.getHours() == 1){currentHours1 = "00";}
	if (Minutes2 == 60){currentMinutes2 = "00";}
	if (Minutes1 == -1){currentMinutes1 = "59";}
	currentTimeString = currentHours + ":" + currentMinutes;
}
if (Clock == "12h"){
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours = ( currentHours == 0 ) ? "12" : currentHours;
	currentHours = ( currentHours == 13 ) ? "01" : currentHours;
	currentHours = ( currentHours == 14 ) ? "02" : currentHours;
	currentHours = ( currentHours == 15 ) ? "03" : currentHours;
	currentHours = ( currentHours == 16 ) ? "04" : currentHours;
	currentHours = ( currentHours == 17 ) ? "05" : currentHours;
	currentHours = ( currentHours == 18 ) ? "06" : currentHours;
	currentHours = ( currentHours == 19 ) ? "07" : currentHours;
	currentHours = ( currentHours == 20 ) ? "08" : currentHours;
	currentHours = ( currentHours == 21 ) ? "09" : currentHours;
	currentHours = ( currentHours == 22 ) ? "10" : currentHours;
	currentHours = ( currentHours == 23 ) ? "11" : currentHours;
	currentHours = ( currentHours == 24 ) ? "12" : currentHours;
	currentHours1 = ( currentHours1 < 10 ? "0" : "" ) + currentHours1;
	currentHours1 = ( currentHours1 == 0 ) ? "12" : currentHours1;
	currentHours1 = ( currentHours1 == 13 ) ? "01" : currentHours1;
	currentHours1 = ( currentHours1 == 14 ) ? "02" : currentHours1;
	currentHours1 = ( currentHours1 == 15 ) ? "03" : currentHours1;
	currentHours1 = ( currentHours1 == 16 ) ? "04" : currentHours1;
	currentHours1 = ( currentHours1 == 17 ) ? "05" : currentHours1;
	currentHours1 = ( currentHours1 == 18 ) ? "06" : currentHours1;
	currentHours1 = ( currentHours1 == 19 ) ? "07" : currentHours1;
	currentHours1 = ( currentHours1 == 20 ) ? "08" : currentHours1;
	currentHours1 = ( currentHours1 == 21 ) ? "09" : currentHours1;
	currentHours1 = ( currentHours1 == 22 ) ? "10" : currentHours1;
	currentHours1 = ( currentHours1 == 23 ) ? "11" : currentHours1;
	currentHours1 = ( currentHours1 == 24 ) ? "12" : currentHours1;
	currentHours2 = ( currentHours2 < 10 ? "0" : "" ) + currentHours2;
	currentHours2 = ( currentHours2 == 0 ) ? "12" : currentHours2;
	currentHours2 = ( currentHours2 == 13 ) ? "01" : currentHours2;
	currentHours2 = ( currentHours2 == 14 ) ? "02" : currentHours2;
	currentHours2 = ( currentHours2 == 15 ) ? "03" : currentHours2;
	currentHours2 = ( currentHours2 == 16 ) ? "04" : currentHours2;
	currentHours2 = ( currentHours2 == 17 ) ? "05" : currentHours2;
	currentHours2 = ( currentHours2 == 18 ) ? "06" : currentHours2;
	currentHours2 = ( currentHours2 == 19 ) ? "07" : currentHours2;
	currentHours2 = ( currentHours2 == 20 ) ? "08" : currentHours2;
	currentHours2 = ( currentHours2 == 21 ) ? "09" : currentHours2;
	currentHours2 = ( currentHours2 == 22 ) ? "10" : currentHours2;
	currentHours2 = ( currentHours2 == 23 ) ? "11" : currentHours2;
	currentHours2 = ( currentHours2 == 24 ) ? "12" : currentHours2;
	if (currentTime.getHours() == 12){currentHours2 = "01";}
	if (currentTime.getHours() == 13){currentHours1 = "12";}
	if (currentTime.getHours() == 0){currentHours2 = "01";}
	if (currentTime.getHours() == 0){currentHours1 = "11";}
	if (currentTime.getHours() == 1){currentHours1 = "12";}
	if (currentTime.getMinutes() == 59){currentMinutes2 = "00";}
	if (currentTime.getMinutes() == 0){currentMinutes1 = "59";}
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hour").innerHTML = currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("hour1").innerHTML = currentHours1;
document.getElementById("minute1").innerHTML = currentMinutes1;
document.getElementById("hour2").innerHTML = currentHours2;
document.getElementById("minute2").innerHTML = currentMinutes2;

document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("date").innerHTML = currentDate;
document.getElementById("month").innerHTML = months[currentTime.getMonth()];
}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}
