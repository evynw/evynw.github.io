window.addEventListener("load", function() {
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentMonth = currentTime.getMonth() + 1;
var currentMonth1 = currentMonth < 10 ? '0' + currentMonth : currentMonth;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

let twentyFourClock = window.config.twentyFourHour;
//let twentyFourClock = false;

if (twentyFourClock){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
} else {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hour").innerHTML = currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("date").innerHTML = currentDate;
document.getElementById("month").innerHTML = shortmonths[currentTime.getMonth()];
document.getElementById("year").innerHTML = currentTime.getFullYear() + " & ";
}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}

//Define Xen HTML api
api.weather.observeData(function (weatherData) {
  console.log('Weather data has updated');

document.getElementById('temp').innerHTML = weatherData.now.temperature.current + "&deg;";
document.getElementById('desc').innerHTML = weatherData.now.condition.description;
document.getElementById('city').innerHTML = weatherData.metadata.address.city;
});

api.resources.observeData(function (resourcesData) {
  document.getElementById('LevelDisplay').innerHTML = resourcesData.battery.percentage + "%";
});

//Set themable elements
document.documentElement.style.setProperty("--textColor", config.textColor);
document.documentElement.style.setProperty("--highlightColor", config.highlightColor);
document.documentElement.style.setProperty("--clockColor", config.clockColor);
