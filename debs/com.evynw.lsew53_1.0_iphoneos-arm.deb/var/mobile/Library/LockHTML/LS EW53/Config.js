/*
Configurations
Credits: Original code by Dacal, Matchstic & Junesiphone.
*/

var Clock = "12h";  // choose between "12h" or "24h"

