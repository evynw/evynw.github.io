/*
Configurations
Credits: Original code by Dacal & Matchstic. Modified by Evelyn.
*/

var Clock = "12h";  // choose between "12h" or "24h"
var useSystemFont = false;   // true to use your system font
var iPX = false;   // switch to true if you're on an iPX