/* 
Configurations
Credits: Original code by Dacal & Junesiphone, modified by Evelyn (@ev_ynw).
*/

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"

