/* 
Configurations
Credits: Original code by Dacal & Matchstic, modified by Evelyn (@ev_ynw).
*/

var Clock = "24h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh", "tr", "kr", "jp"
var hideCal = false;   // switch on to hide top calendar line
