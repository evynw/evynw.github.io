window.addEventListener("load", function() {
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes1 = currentTime.getMinutes();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds1 = currentTime.getSeconds();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
var currentMonth = currentTime.getMonth() + 1;
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

if (Clock == "24h"){
	timeOfDay = "";
	currentHours1 = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
	document.getElementById("RHour").style.height = ((currentHours / 24) * 165) + 'px';
	document.getElementById("RHour").style.top = (165 - ((currentHours / 24) * 165)) + 'px';
}
if (Clock == "12h"){
	currentHours1 = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentHours1 = ( currentHours == 0 ) ? "12" : currentHours;
	currentHours1 = ( currentHours == 13 ) ? "01" : currentHours;
	currentHours1 = ( currentHours == 14 ) ? "02" : currentHours;
	currentHours1 = ( currentHours == 15 ) ? "03" : currentHours;
	currentHours1 = ( currentHours == 16 ) ? "04" : currentHours;
	currentHours1 = ( currentHours == 17 ) ? "05" : currentHours;
	currentHours1 = ( currentHours == 18 ) ? "06" : currentHours;
	currentHours1 = ( currentHours == 19 ) ? "07" : currentHours;
	currentHours1 = ( currentHours == 20 ) ? "08" : currentHours;
	currentHours1 = ( currentHours == 21 ) ? "09" : currentHours;
	currentHours1 = ( currentHours == 22 ) ? "10" : currentHours;
	currentHours1 = ( currentHours == 23 ) ? "11" : currentHours;
	currentHours1 = ( currentHours == 24 ) ? "12" : currentHours;
	currentHours2 = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
	document.getElementById("RHour").style.height = ((currentHours2 / 12) * 165) + 'px';
	document.getElementById("RHour").style.top = (165 - ((currentHours / 12) * 165)) + 'px';
}

document.getElementById("hour").innerHTML = currentHours1;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("second").innerHTML = currentSeconds;
document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("weekday").innerHTML = shortdays[currentTime.getDay()];
document.getElementById("date").innerHTML = currentTime.getDate();
document.getElementById("month").innerHTML = shortmonths[currentTime.getMonth()];

document.getElementById("RMin").style.height = ((currentMinutes1 / 60) * 165) + 'px';
document.getElementById("RMin").style.top = (165 - ((currentMinutes1 / 60) * 165)) + 'px';

document.getElementById("RSec").style.height = ((currentSeconds1 / 60) * 165) + 'px';
document.getElementById("RSec").style.top = (165 - ((currentSeconds1 / 60) * 165)) + 'px';
}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}
