/* 
Configurations
Credits: Original code by Dacal & Junesiphone & Matchstic. Modified by Evelyn.
*/

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", or "cz"

var IconSet = "Outlined";   // choose your weather icon pack here

