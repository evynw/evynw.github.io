/* 
Configurations
Credits: Original code by Dacal & Junesiphone. Modified by Evelyn (@ev_ynw).
*/

var Clock = "12h";  // choose between "12h" or "24h"

var r1Color = "#222";   // color of the icon holder; enter hex or rgba() code
var r2Color = "#222";   // color of the music player background; enter hex or rgba() code
