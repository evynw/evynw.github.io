/*
Configurations
Credits: Original code by Dacal & Junesiphone. Modified by Evelyn.
*/

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh", "tr"
var IconSet = "Outlined";   // choose your weather icon pack here

var battDefaultColor = "#f8f8f8";   // default color of battery idicator while not charging; enter hex or rgba() code
var chargingColor = "#64e782";   // color of battery indicator (fill) while charging; enter hex or rgba() code
