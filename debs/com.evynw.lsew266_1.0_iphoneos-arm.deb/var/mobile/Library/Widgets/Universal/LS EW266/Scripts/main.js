window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);

function updateClock() { 
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes() < 10 ? '0' + currentTime.getMinutes() : currentTime.getMinutes();
var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

let twentyFourClock = window.config.twentyFourHour;
//let twentyFourClock = false;

if (twentyFourClock){
	timeOfDay = "";
	currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
	currentTimeString = currentHours + ":" + currentMinutes;
} else {
  currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
  currentHours = ( currentHours == 0 ) ? 12 : currentHours;
  currentTimeString = currentHours + ":" + currentMinutes;
}

document.getElementById("hour").innerHTML = currentHours;
document.getElementById("minute").innerHTML = currentMinutes;
document.getElementById("ampm").innerHTML = timeOfDay;
document.getElementById("weekday").innerHTML = shortdays[currentTime.getDay()];
document.getElementById("date").innerHTML = currentDate;
document.getElementById("month").innerHTML = shortmonths[currentTime.getMonth()];
}

function init(){
updateClock();
setInterval("updateClock();", 1000);
}

//Define Xen HTML api
api.resources.observeData(function (resourcesData) {
  document.getElementById('LevelDisplay').innerHTML = resourcesData.battery.percentage + "%";

  if (resourcesData.battery.state == 0) {
    document.getElementById("StateDisplay").innerHTML = "Draining";
  } else if (resourcesData.battery.state == 1){
    document.getElementById("StateDisplay").innerHTML = "Charging";
  } else {
    document.getElementById("StateDisplay").innerHTML = "Fully Charged";
  }
});


//Set themable elements
document.documentElement.style.setProperty("--textColor", config.textColor);
document.documentElement.style.setProperty("--highlightColor", config.highlightColor);
