/*
Configurations
Credits: Original code by Dacal & Junesiphone. Modified by Evelyn.
*/

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"

/* Style change options */
var gradientColor1 = "rgba(34,118,170,0.8)";   // 1st color in gradient; enter hex or rgba() code
var gradientColor2 = "rgba(158,198,229,0.2)";  // 2nd color in gradient; enter hex or rgba() code
