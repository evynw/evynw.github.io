/*
Configurations
Credits: Original code by Dacal & Junesiphone. Modified by Evelyn.
*/

var Clock = "12h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh", "tr"
var IconSet = "Shadow";   // choose your weather icon pack here
var invertColour = false;   // true to invert the colours of the blocks

